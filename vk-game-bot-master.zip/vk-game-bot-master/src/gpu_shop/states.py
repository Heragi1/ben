from vkbottle import BaseStateGroup


class GPUShopState(BaseStateGroup):
    BUY_GPU = 0
    SELL_GPU = 1
