from vkbottle import BaseStateGroup


class RegisterState(BaseStateGroup):
    CHOOSE_SKIN_COLOR = 0
    CHOOSE_FACE = 1
    CHOOSE_HAIRCUT = 2
    ENTER_NICKNAME = 3
